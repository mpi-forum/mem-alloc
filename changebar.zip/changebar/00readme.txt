                               changebar bundle

                               September 19, 2005

This bundle contains a package that I maintain to add changebars to a
LaTeX document.

It provides the changebar environment as well as the commands cbstart
and cbend. It uses \specials to communicate to the dvi driver where
the bars should be printed.

The file chbar.sh which is part of this bundle was contributed. It can
be used to compare two versions of a document and automatically add
the changebars.
The file chbar.1, also contributed, documents the workings of chbar.sh

Copyright (C) 2005 Johannes L. Braams texniek(at)braams.cistron.nl

This program can be redistributed and/or modified under the terms
of the LaTeX Project Public License Distributed from CTAN
archives in directory macros/latex/base/lppl.txt; either
version 1.3 of the License, or any later version.



